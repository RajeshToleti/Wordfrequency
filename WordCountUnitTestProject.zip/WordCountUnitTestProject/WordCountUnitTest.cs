using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.IO;
using WordCount;

namespace WordCountUnitTestProject
{
    [TestClass]
    public class WordCountTests
    {
        [TestMethod]
        public void Check_Print()
        {

            // Arrange

            WordFrequency wf = new WordFrequency("test", "test");
            Dictionary<string, int> wordFreqDic = new Dictionary<string, int>();

            wordFreqDic.Add("The", 3);
            wordFreqDic.Add("To", 2);
            wordFreqDic.Add("Yes", 4);

            // Act
            
            wf.PrintFrequency(wordFreqDic);

            // Assert

            //check the additional output window

           
            
            
            
        }

        [TestMethod]
        public void Check_Processing()
        {

            // Arrange
            string filePath = "C:\\CV\\mobydick.txt";

            WordFrequency wf = new WordFrequency(filePath, "txt");
            var content = File.ReadAllText(filePath).ToLower();

            // Act

            wf.DoProcessing(content);

            // Assert

            //check the additional output window





        }
    }
}
